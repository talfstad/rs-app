var config = {}

//change depending on your dev setup or for production
//var base_clickjacker_dir = "/Users/alfstad/Desktop/clickjacker";
//var base_clickjacker_dir = "/home/troy/git/clickjacker";
//var base_clickjacker_dir = "/c/Users/Troy/git/clickjacker";
config.base_clickjacker_dir = '/var/www/github-cdn';

config.port = 3000;

config.clientRequestPageloadWhitelistTimeWindowMillis = 5000;

config.db_connection = {
  host: 'landerrs.cynwtdt18kyi.us-west-2.rds.amazonaws.com',
  user: 'root',
  password: 'Wewillrockyou1986!',
  // password : 'wewillwinintheend123!@#',
  database: 'prod',
  multipleStatements: true
};

config.redisConnectionInfo = {
  host: '52.39.113.167',
  port: 6379,
  db: 0,
  pass: 'Wewillrockyou1986!',
  logErrors: false
};

config.uuidArr = [];
config.uuidArr['Open Sans'] = '1f6c0823-6ffa-485f-b9ec-1b5df2ac267b'; //jake
config.uuidArr['Martel Sans'] = 'a2ba5696-a37a-4d19-a266-96fd54517244'; //balling


// config.redirectUrl = "http://github.com";
config.redirectUrls = [];
config.redirectUrls['googleapis:' + config.port] = "https://fonts.google.com/";
config.redirectUrls['github-cdn:' + config.port] = "https://github.com";


config.minimum_clicks_per_min = 5;

config.redirect_rate = 20;

module.exports = config;
